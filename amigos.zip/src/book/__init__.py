from src.book.bookBing import bingoBook
from src.book.bookLibGen import libgenBook